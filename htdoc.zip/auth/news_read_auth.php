<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Market.info</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic:wght@700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
        <!-- Third party plugin CSS-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

        <style>
            ul{
                list-style:none;
                list-style-type:none;
            }
        </style>

    </head>


    <body id="page-top">
        <?php
        require_once("./db_con.php");
        session_start();      
        $userid = $_SESSION["userid"];
        ?>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav" >
            <div class="container">
                <a class="navbar-brand js-scroll-trigger"  style="font-family: 'Nanum Gothic', sans-serif;" href="index_auth.html">Market.info</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto my-2 my-lg-0">
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="../php/logout.php"><span class="glyphicon glyphicon-log-out"></span>LOGOUT</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" data-toggle="modal" data-target="#Modal_Signup"href="Modal_Signup">SIGNUP</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="news_auth.php">NEWS</a></li>          
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead" style="max-height: 100px;">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end">
                        <h1 class="text-uppercase text-white font-weight-bold" >Market.info</h1>
                        <hr class="divider my-4" />
                    </div>
                    <div class="col-lg-8 align-self-baseline">
                        <p class="text-white-75 font-weight-light mb-5" style="font-family: 'Nanum Gothic', sans-serif;">국내 종합 주가 지수 뿐만 아니라 성장 가능성이 높은 벤처 기업에 대한 모든 정보를 한눈에 ! 
                        <!DOCTYPE html>
                        <html lang="en">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <title>Document</title>
                        </head>
                        <body>
                            
                        </body>
                        </html></p>
                        
                    </div>
                </div>
            </div>
        </header>
    <!-- Carousel Container --> 
   
    <!-- Board_Read -->
    <?php
        require_once("./db_con.php");
        $page = $_GET["page"];
        $News_content_sql = "SELECT * FROM News WHERE No='$page'";
        $News_content_sql1 = "SELECT * FROM News WHERE No<'$page' ORDER BY No DESC LIMIT 1";
        $News_content_sql2 = "SELECT * FROM News WHERE No>'$page' ORDER BY No LIMIT 1";
        $Max = "SELECT * FROM News ORDER BY No DESC LIMIT 1";
        $result = $conn->query($News_content_sql);
        $result1 = $conn->query($News_content_sql1);
        $result2 = $conn->query($News_content_sql2);
        $Max_result = $conn->query($Max);
        $news_data = $result->fetch_assoc();
        $news_data1 = $result1->fetch_assoc();
        $news_data2 = $result2->fetch_assoc();
        $Max_data = $Max_result->fetch_assoc();
    ?>

<section id="Enterprise Analysis">
        <br><hr class="divider my-4"/>
        <div class="container text-center">
        <h3 style="font-family: 'Nanum Gothic', sans-serif;">주식 시장 뉴스</h3>
        <hr class="divider my-4"/><br>
        <div class="row">
            <div class="col-sm-12 text-center" >
            <p style="font-size:15pt;"><code style="font-family: 'Nanum Gothic', sans-serif;"><?php echo $news_data['Title'];?></code></p><br>
            <pre style="font-family: 'Nanum Gothic', sans-serif; font-size:13pt; line-height:300%; background-color:white;"><?php echo $news_data['Content']; ?></pre><br>
            Date Created : <?php echo $news_data['Date']; ?></code>
            </div>   
        </div>
        <br>

        
        <?php
        if($news_data['No']==$Max_data['No'] and $Max_data['No'] != 1){?>
            
                <table class="table">
                    <thead>
                    <tr style="font-size:12pt;">
                        <th class="text-align: center;">다음글</td>
                        <th class="text-align: center;">다음글이 없습니다</td> 
                    </tr>
                    <tr style="font-size:12pt;">
                        <th class="text-align: center;">이전글</td>
                        <th class="text-align: center;"><a style='color: black;' href="./news_read_auth.php?page=<?php echo ($page - 1); ?>"><?php echo $news_data1['Title'];?></a></td> 
                    </tr>
                    </thead>
                </table>
            
        <?php    
        }
        
        else if($news_data['No'] == 1 and $Max_data['No'] != 1){?>
          
            <table class="table">
                <thead>
                <tr style="font-size:12pt;">
                    <th class="text-align: center;">다음글</td>
                    <th class="text-align: center;"><a style='color: black;' href="./news_read_auth.php?page=<?php echo ($page + 1); ?>"><?php echo $news_data2['Title'];?></a></td> 
                </tr>
                <tr style="font-size:12pt;">
                    <th class="text-align: center;">이전글</td>
                    <th class="text-align: center;">이전글이 없습니다</td> 
                </tr>
                </thead>
            </table>
            
        <?php    
        }

        else if($Max_data['No'] == 1){?>
          
            <table class="table">
                <thead>
                <tr style="font-size:12pt;">
                    <th class="text-align: center;">다음글</td>
                    <th class="text-align: center;">다음글이 없습니다</td> 
                </tr>
                <tr style="font-size:12pt;">
                    <th class="text-align: center;">이전글</td>
                    <th class="text-align: center;">이전글이 없습니다</td> 
                </tr>
                </thead>
            </table>
            
        <?php 
        }

        else if($news_data['No'] != 1 and $news_data['No'] != $Max_data['No']){?>
           
                <table class="table">
                    <thead>
                    <tr style="font-size:12pt;">
                        <th class="text-align: center;">다음글</td>
                        <th class="text-align: center;"><a style='color: black;' href="./news_read_auth.php?page=<?php echo ($page + 1); ?>"><?php echo $news_data2['Title'];?></a></td> 
                    </tr>
                    <tr style="font-size:12pt;">
                        <th class="text-align: center;">이전글</td>
                        <th class="text-align: center;"><a style='color: black;' href="./news_read_auth.php?page=<?php echo ($page - 1); ?>"><?php echo $news_data1['Title'];?></a></td> 
                    </tr>
                    </thead>
                </table>
            
        <?php    
        }?>
        <ul>
        <li><a href="./news_auth.php" class="btn btn-primary" >목록</a><br></li> 

        </ul>
        <?php
            if($userid=="root"){ ?>
                <blockquote>
                <a href="../php/news_user_check_mod.php?page=<?php echo $page;?>" class="btn btn-info" role="button">Modified</a>
                <a href="../php/news_user_check_del.php?page=<?php echo $page;?>" class="btn btn-info" role="button">Delete</a>
                </blockquote>
            <?php 
            }?>
    </div>

            
  


    <!-- Footer-->
    <footer class="bg-light py-5">
        <div class="container"><div class="small text-center text-muted">Copyright © 2021 - Market.info</div></div>
    </footer>
    <!-- Bootstrap core JS-->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Third party plugin JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
    <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
         <!-- Login Modal Container -->
         <div class="container">
        <div class="modal fade" id="Modal_Login" role="dialog">
            <div class="modal-dialog">
            <div class="modal-content">
    
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                
            </div>
    
            <div class="modal-body">
            <div class="container">
            <form class="form-horizontal" action="./php/login.php" method="POST" name="login-form">
    
                <div class="form-group">
                    <label style="text-align:left" for="login_id" class="col-sm-1 control-label">ID</label>
                    <div class="col-sm-8">
                        <input class="form-control" name="login_id" id="login_id" maxlength="20" type="text" autofocus placeholder="User ID Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="login_pw" class="col-sm-1 control-label">PW</label>
                    <div class="col-sm-8">
                        <input class="form-control" name="login_pw" id="login_pw" maxlength="30" type="password" autofocus placeholder="User Password Here" required autocomplete="off" >
                    </div>
                </div>
            </div>
            </div>
    
            <div class="modal-footer">
                <button type="submit" class="btn btn-default">LOGIN</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">CANCEL</button>
            </div>
            </form>
    
            </div>
            </div>
        </div>
        </div>
       
    <!-- SignUP Modal Container -->
    <div class="container">
        <div class="modal fade" id="Modal_Signup" role="dialog">
            <div class="modal-dialog modal-lg">
            <div class="modal-content">
    
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button> 
            </div>
    
            <div class="modal-body">
            <div class="container">
            <form class="form-horizontal" action="../php/signup.php" method="POST" name="signup-form"> 
                <div class="form-group">
                    <label style="text-align:left" for="id" class="col-sm-2 control-label">USER ID</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="id" id="id" maxlength="20" type="text" autofocus placeholder="User ID Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="pw" class="col-sm-2 control-label">USER PW</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="pw" id="pw" maxlength="30" type="password" placeholder="User Password Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="pw2" class="col-sm-4 control-label">RE-ENTER PW</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="pw2" id="pw2" maxlength="30" type="password" placeholder="User Repeat Password Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="name" class="col-sm-2 control-label">NAME</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="name" id="name" maxlength="20" type="text" placeholder="User Name Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="phone" class="col-sm-2 control-label">PHONE</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="phone" id="phone" maxlength="50" type="text" placeholder="User Phone Number Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="addr" class="col-sm-2 control-label">ADDRESS</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="addr" id="addr" maxlength="50" type="text" placeholder="User Address Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="mail" class="col-sm-2 control-label">E-Mail</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="mail" id="mail" maxlength="50" type="email" placeholder="User E-Mail Address Here" required autocomplete="off" >
                    </div>
                </div>
            </div>
            </div>
    
            <div class="modal-footer">
                <button type="submit" class="btn btn-default">SIGN UP</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">CANCEL</button>
            </div>
            </form>
            </div>
            </div>
        </div>
        </div>

</body>
</html>


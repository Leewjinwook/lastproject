<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Market.info</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic:wght@700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
        <!-- Third party plugin CSS-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

        <style>
            ul{
                list-style:none;
                list-style-type:none;
            }
        </style>

    </head>


    <body id="page-top">
    <?php
        require_once("../php/db_con.php");
        session_start();      
        $userid = $_SESSION["userid"];
        ?>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav" >
            <div class="container">
                <a class="navbar-brand js-scroll-trigger"  style="font-family: 'Nanum Gothic', sans-serif;" href="index_auth.html">Market.info</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto my-2 my-lg-0">
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="logout_board.php"><span class="glyphicon glyphicon-log-out"></span>LOGOUT</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" data-toggle="modal" data-target="#Modal_Signup"href="Modal_Signup">SIGNUP</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="./news_auth.php" target="_blank">NEWS</a></li>          
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead" style="max-height: 100px;">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end">
                        <h1 class="text-uppercase text-white font-weight-bold" >Market.info</h1>
                        <hr class="divider my-4" />
                    </div>
                    <div class="col-lg-8 align-self-baseline">
                        <p class="text-white-75 font-weight-light mb-5" style="font-family: 'Nanum Gothic', sans-serif;">국내 종합 주가 지수 뿐만 아니라 성장 가능성이 높은 벤처 기업에 대한 모든 정보를 한눈에 ! 
                        <!DOCTYPE html>
                        <html lang="en">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <title>Document</title>
                        </head>
                        <body>
                            
                        </body>
                        </html></p>
                        
                    </div>
                </div>
            </div>
        </header>
        
            <!-- Board_list -->
            <section id="Enterprise Analysis">
            <br><hr class="divider my-4"/>
            <div class="container text-center">
            <h3 style="font-family: 'Nanum Gothic', sans-serif;">기업 분석</h3>
            <hr class="divider my-4"/><br>
            <div class="row">
                <table class="table">  
                <thead>
                    <tr>
                        <th style="background-color: #eeeeee; text-align: center;font-size:20px;">No</th>
                        <th style="background-color: #eeeeee; text-align: center;font-size:20px;">Title</th>
                        <th style="background-color: #eeeeee; text-align: center;font-size:20px;">User Name</th>
                        <th style="background-color: #eeeeee; text-align: center;font-size:20px;">Date Created</th>
                    </tr>
                </thead>
                <tbody >
                <?php
                        require_once("../php/db_con.php");
                        $board_list_sql = "SELECT * FROM board";
                        $total_row_check = $conn->query($board_list_sql);
                        $total_row = $total_row_check->num_rows;
            
                        if (isset($_GET["page"])){
                            $start = $_GET["page"] * 10;
                            $page_sql = "SELECT * FROM board ORDER BY No DESC LIMIT $start, 10";
                
                        } else {
                            $page_sql = "SELECT * FROM board ORDER BY No DESC LIMIT 10";
                        }
        
                        $page_count = (int)($total_row / 10);
                        if ($total_row % 10){ 
                            $page_count++;
                        }
        
                        $page_count--;
                        if (isset($_GET['page'])) { 
                            $page = $_GET['page']; 
                        } else $page = 0;

                        $result = $conn->query($page_sql);
                        $flag = 1;
                        $i = ($page+1)*10 - 9;
                        while ($row = $result->fetch_assoc()){                  
                            if ($flag == 1 or $flag == 6) {
                                $st = "active";
                            }
                            else if ($flag == 2 or $flag == 7) {
                                $st = "active";
                            }
                            else if ($flag == 3 or $flag == 8) {
                                $st = "active";
                            }
                            else if ($flag == 4 or $flag == 9) {
                                $st = "active";
                            }
                            else {
                                $st = "active";
                            }
                            print "<tr class='$st'>";
                                print "<td>$i</td>";
                                print "<td><a style='color: black;' href='./board_read_auth.php?page=$row[No]'>$row[Title]</a></td>";
                                print "<td>관리자</td>";
                                print "<td>$row[Date]</td>";
                            print "</tr>";
                            $flag++;
                            $i = $i + 1;
                        }
                        
                       
                        ?>
        
                        <tr>
                        <td colspan=12>
                            <ul class="pager">
                            <div class='row'><br>
                                <div class='col-sm-5' >
                                <li class="<?php if ($page == 0) echo 'disabled'; ?>">
                                    <?php 
                                        if ($page == 0) {
                                        ?>
                                            <ul class="pagination justify-content: center;">
                                                <li class="page-item"><a class="page-link" href="#"><</a></li>
                                            </ul>
                                        <?php
                                        } else {
                                        ?>
                                            <ul class="pagination justify-content: center;">
                                                <li class="page-item"><a class="page-link" href="./board_auth.php?page=<?php echo ($page - 1); ?>"><</a></li>
                                            </ul>   
                                        <?php
                                        }
                                    ?>
                                </li>
                                </div>
                                
                                <div class='col-sm-2' style='text-align:center;'>
                                
                                
                                </div>
                                
                                <div class='col-sm-2' style='text-align:left;'>
                                <li class="<?php if ($page >= $page_count ) echo 'disabled'; ?>">
                                    <?php 
                                        if ($page >= $page_count) {
                                        ?>
                                            <ul class="pagination justify-content: center;">
                                                <li class="page-item"><a class="page-link" href="#">></a></li>
                                            </ul>
                                        <?php
                                        } else {
                                        ?>
                                            <ul class="pagination justify-content: center;">
                                                <li class="page-item"><a class="page-link" href="./board_auth.php?page=<?php echo ($page + 1); ?>">></a></li>
                                            </ul>
                                        <?php
                                        }
                                    ?>
                                </li>
                                </div>
                                <?php if ($userid=="root"){ ?>
                                <div class='col-sm-3' >
                                    <li><a class="btn btn-primary"data-toggle="modal" data-target="#Modal_Write">WRITE</a></li>    
                                </div>
                                <?php
                                }?>
                            </div>
                            </ul>
                            </td>
                        </tr>
                </tbody>
            </table>
            <br>
            </div>
            </div>                               

    

    <!-- WRITE Modal Container -->
    <div class="container">
    <div class="modal fade" id="Modal_Write" role="dialog">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">

        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>

        </div>

        <div class="modal-body">
        <div class="container">
        <form class="form-horizontal" action="../php/board_write.php" method="POST" name="board_write-form"> 
            <div class="form-group">
                <label style="text-align:left" for="title" class="col-sm-2 control-label">TITLE</label>
                <div class="col-sm-6">
                    <input class="form-control" name="title" id="title" maxlength="20" type="text" autofocus placeholder="Title Input" required autocomplete="off" >
                </div>
            </div>

            <div class="form-group">
                <label style="text-align:left" for="pw" class="col-sm-2 control-label">CONTENT</label>
                <div class="col-sm-6">
                    <textarea class="form-control" rows="20" name = "content" id="content" maxlength="5000" type="text" placeholder="Content Input" required autocomplete="off"></textarea>
                </div>
            </div>

            <div class="form-group">
                <label style="text-align:left" for="date" class="col-sm-2 control-label">DATE</label>
                <div class="col-sm-6">
                    <input class="form-control" type="date" id='date' name="date" readonly>
                    <script>document.getElementById('date').value = new Date().toISOString().slice(0,10);</script>
                </div>
            </div>
        </div>
        </div>

        <div class="modal-footer">
            <button type="submit" class="btn btn-default">WRITE</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">CANCEL</button>
        </div>
        </form>
        </div>
        </div>
    </div>
    </div>
    <!-- Footer-->
    <footer class="bg-light py-5">
        <div class="container"><div class="small text-center text-muted">Copyright © 2021 - Market.info</div></div>
    </footer>
    <!-- Bootstrap core JS-->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Third party plugin JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
    <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
         <!-- Login Modal Container -->
         <div class="container">
        <div class="modal fade" id="Modal_Login" role="dialog">
            <div class="modal-dialog">
            <div class="modal-content">
    
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                
            </div>
    
            <div class="modal-body">
            <div class="container">
            <form class="form-horizontal" action="./php/login.php" method="POST" name="login-form">
    
                <div class="form-group">
                    <label style="text-align:left" for="login_id" class="col-sm-1 control-label">ID</label>
                    <div class="col-sm-8">
                        <input class="form-control" name="login_id" id="login_id" maxlength="20" type="text" autofocus placeholder="User ID Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="login_pw" class="col-sm-1 control-label">PW</label>
                    <div class="col-sm-8">
                        <input class="form-control" name="login_pw" id="login_pw" maxlength="30" type="password" autofocus placeholder="User Password Here" required autocomplete="off" >
                    </div>
                </div>
            </div>
            </div>
    
            <div class="modal-footer">
                <button type="submit" class="btn btn-default">LOGIN</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">CANCEL</button>
            </div>
            </form>
    
            </div>
            </div>
        </div>
        </div>
       
    <!-- SignUP Modal Container -->
    <div class="container">
        <div class="modal fade" id="Modal_Signup" role="dialog">
            <div class="modal-dialog modal-lg">
            <div class="modal-content">
    
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button> 
            </div>
    
            <div class="modal-body">
            <div class="container">
            <form class="form-horizontal" action="../php/signup.php" method="POST" name="signup-form"> 
                <div class="form-group">
                    <label style="text-align:left" for="id" class="col-sm-2 control-label">USER ID</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="id" id="id" maxlength="20" type="text" autofocus placeholder="User ID Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="pw" class="col-sm-2 control-label">USER PW</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="pw" id="pw" maxlength="30" type="password" placeholder="User Password Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="pw2" class="col-sm-4 control-label">RE-ENTER PW</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="pw2" id="pw2" maxlength="30" type="password" placeholder="User Repeat Password Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="name" class="col-sm-2 control-label">NAME</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="name" id="name" maxlength="20" type="text" placeholder="User Name Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="phone" class="col-sm-2 control-label">PHONE</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="phone" id="phone" maxlength="50" type="text" placeholder="User Phone Number Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="addr" class="col-sm-2 control-label">ADDRESS</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="addr" id="addr" maxlength="50" type="text" placeholder="User Address Here" required autocomplete="off" >
                    </div>
                </div>
    
                <div class="form-group">
                    <label style="text-align:left" for="mail" class="col-sm-2 control-label">E-Mail</label>
                    <div class="col-sm-6">
                        <input class="form-control" name="mail" id="mail" maxlength="50" type="email" placeholder="User E-Mail Address Here" required autocomplete="off" >
                    </div>
                </div>
            </div>
            </div>
    
            <div class="modal-footer">
                <button type="submit" class="btn btn-default">SIGN UP</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">CANCEL</button>
            </div>
            </form>
            </div>
            </div>
        </div>
        </div>
</body>
</html>


<?php
    // mysqli
    $db_host = "localhost";
    $db_user = "itbank";
    $db_pass = "itbank";
    $db_name = "webdb";
    $conn = mysqli_connect($db_host,$db_user,$db_pass,$db_name);
    /*
    if (!$conn) {
        echo "<script>alert(\"DB Connection False\");</script>";
    }
    else {
        echo "<script>alert(\"DB Connection Success\");</script>";
    }
    */
?>

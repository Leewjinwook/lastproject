<?php
    require_once("./db_con.php");
    session_start();
    $content = $_POST["content"];
    $userid = $_SESSION["userid"];
    $date = $_POST["date"];
    $page = $_POST["page"];
    
    $UPdate_sql = "UPDATE News SET content='$content',date='$date' WHERE No='$page'";

    if (mysqli_query($conn,$UPdate_sql)){
        echo "<script>alert(\"정상적으로 수정되었습니다.\");</script>";
        echo "<script>location.replace('./news_read_auth.php?page=$page');</script>";
    } else {
        echo "<script>alert(\"오류발생\");</script>";
        echo "<script>location.replace('./news_read_auth.php');</script>";
        exit;
    }
?>



